---
layout: subcategory
title: Household
description: Household stuff.
type: category
permalink: /category/household
---
