---
layout: product
title: Chair
description: This is a chair.
type: product
permalink: /category/household/chair
---
