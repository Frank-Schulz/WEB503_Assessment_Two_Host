---
layout: subcategory
title: Electronics
description: Electrical stuff.
type: category
permalink: /category/electronics
---
